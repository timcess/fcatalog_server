FCatalog python library
=======================

A basic library that implements the server logic of the fcatalog server.
It uses asyncio for communication and sqlite3 python bindings for db.


