# Base path for databases:
DB_BASE_PATH = '/var/lib/fcatalog/'

# Amount of hashes for signature:
NUM_HASHES = 16

